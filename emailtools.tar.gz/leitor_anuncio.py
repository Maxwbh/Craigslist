# -*- encoding: utf-8 -*-

__author__ = 'Maxwell'

from datetime import datetime, date, time
import re
from bs4 import BeautifulSoup
from sqlalchemy.exc import (IntegrityError, OperationalError)

from class_map import *
from util import *



def load_html(link_int, html_int, str_cidade, str_estado, str_sessao, str_regiao, source, str_whitelist=[], str_blacklist=[],contador=0):


    ###########################
    # Leitura do anuncio      #
    ###########################
    soup_int = BeautifulSoup(html_int)
    texto = ''
    if source == 'craigslist.org':
        texto = soup_int.find('section', id="userbody")
    elif source == 'ebayclassifieds.com':
        texto = soup_int.find('div', id="ad-details")
    elif source == 'backpage.com':
        _texto = soup_int.find('div')
        for i in _texto:
            if i.get('class')=='postingBody':
                texto = i

    if not texto :
        texto = soup_int.text
    else:
        texto = texto.text

    #########################
    # White List            #
    #########################
    in_white_list = (str_whitelist and check_data(texto ,str_whitelist)) or ( not str_whitelist )


    #########################
    # Black List            #
    #########################
    in_blak_list = False
    if in_white_list  and check_data(texto ,str_blacklist):
        in_blak_list = True

    if in_blak_list:
        return {'info':'Html em Black List ou não incluso na Withe List'}

    #######################
    # Tratar anuncio p/   #
    #    Insercao         #
    ############################
    # Não esta na Black List   #
    # Esta na White List ou [] #
    ############################


    if source == 'craigslist.org':
        try:

            time_sec = soup_int.find('time').text
            body_sec = soup_int.find('section', id="userbody")
            body_texto = body_sec.text
            email = soup_int.find('span',id='replytext')
            email = email.find_next("a").text

            if not email or not '@' in email:
                tipo_mail = -1
                email = ''
            elif ('craiglist.org') in email:
                tipo_mail = 0
            else:
                tipo_mail = 1

            titulo = soup_int.find_all('title')[0].text
            titulo_id = re.sub(r"[^A-Za-z0-9]",'_',titulo).replace('__','_')
            phone = get_phone(body_texto )
            tags = get_tags(body_texto )
            time_sec = datetime.strptime(time_sec[:19], "%Y-%m-%d, %I:%M%p")
        except :
            return {'warning':'Erro na identificação dos elementos do HTML'}
            #raise

    elif source == 'ebayclassifieds.com':
        try:

            _time_sec = soup_int.find('div',id='ad-details').find_all('span')
            time_sec  = datetime.strptime('01/01/1500', "%m/%d/%Y")
            for i in _time_sec:
                try:
                    time_sec = datetime.strptime(i.text, "%m/%d/%y")
                    break
                except:
                    pass



            body_texto = texto
            email = ''
            tipo_mail = -1
            # Titulo da pagina
            titulo = soup_int.find_all('title')[0].text[:99]
            # Titulo do Anuncio
            #titulo = soup_int.find_all('h1',id='ad-title')[0].text

            titulo_id = re.sub(r"[^A-Za-z0-9]",'_',titulo).replace('__','_')
            phone = get_phone(body_texto )
            tags = get_tags(body_texto )
        except :
            #return {'warning':'Erro na identificação dos elementos do HTML'}
            raise
    elif source == 'backpage.com':
        try:

            _time_sec = soup_int.find('div',id='postingTitle').find_all('div')
            time_sec  = datetime.strptime('01/01/1500', "%m/%d/%Y")
            for i in _time_sec:
                try:
                    time_sec = datetime.strptime(i.text, "%m/%d/%y")
                    break
                except:
                    pass



            body_texto = texto
            email = ''
            tipo_mail = -1
            # Titulo da pagina
            titulo = soup_int.find_all('title')[0].text[:99]
            # Titulo do Anuncio
            #titulo = soup_int.find_all('h1',id='ad-title')[0].text

            titulo_id = re.sub(r"[^A-Za-z0-9]",'_',titulo).replace('__','_')
            phone = get_phone(body_texto )
            tags = get_tags(body_texto )
        except :
            #return {'warning':'Erro na identificação dos elementos do HTML'}
            raise



    try:
        sel_anuncio = session_cm.query(Anuncios).filter_by(url_id=titulo_id).first()
        if not sel_anuncio :
            print '--> Ins Anuncio'
            session_cm.add_all([Anuncios(
                k=chave(),
                nome = titulo,
                url_id = titulo_id,
                url = link_int,
                html = soup_int.encode('utf-8'),
                tags = tags,
                cidade = str_cidade,
                estado = str_estado,
                regiao = str_regiao,
                sessao = str_sessao,
                has_phone = phone and 1 or 0,
                emails_type = tipo_mail,
                post_date = time_sec.strftime("%Y-%m-%d, %H:%M:00"),
                status = '1'
            )])
            if tipo_mail in (1,2):
                print '---> Ins Email'
                session_cm.add_all([AnunciosEmails(
                    k=chave(),
                    nome = email,
                    url_id = re.sub(r"[^A-Za-z0-9]",'_',email).replace('__','_'),
                    tipo = tipo_mail == 1  and 'CRAIGSLIST'  or 'EXTERNAL',
                    anuncio= titulo_id,
                    regiao = str_regiao)])
            if phone:
                print '---> Ins Phone'
                session_cm.add_all([AnunciosTelefones(
                    k=chave(),
                    nome = phone,
                    url_id = re.sub(r"[^A-Za-z0-9]",'_',phone).replace('__','_'),
                    anuncio= titulo_id)])

        #else:
        #    print 'Anuncio Já cadastrado'
        #    sel_anuncio.nome = titulo
        #    sel_anuncio.url_id = titulo_id
        #    sel_anuncio.url = link_int
        #    sel_anuncio.html = soup_int.encode('utf-8')
        #    sel_anuncio.tags = tags.encode('utf-8')
        #    sel_anuncio.cidade = str_cidade
        #    sel_anuncio.estado = str_estado
        #    sel_anuncio.regiao =str_regiao
        #    sel_anuncio.sessao = str_sessao
        #    sel_anuncio.has_phone = phone and 1 or 0
        #    sel_anuncio.post_date = time_sec.strftime("%Y-%m-%d, %H:%M:00")
        #    sel_anuncio.status = '1'
        session_cm.commit()
    except (OperationalError, IntegrityError ):
        session_cm.rollback()
    return {}
