# -*- encoding: utf-8 -*-

__author__ = 'Maxwell'

import logging
import urllib
from datetime import datetime, date, time
import re
from bs4 import BeautifulSoup
from sqlalchemy import (create_engine, Column, Integer,
                        String, DateTime,Text, text, Float, ForeignKey, and_)
from sqlalchemy.orm import Session
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.exc import (IntegrityError, OperationalError)

from class_map import *
from util import *





if __name__ == '__main__':

#    """
#    FORMAT = "%(asctime)-15s %(message)s"
#    logging.basicConfig(format=FORMAT)
#    logging.warning("Protocol problem: %s", "connection reset", extra="Start Connection")
#    """


    sel = session_cm.query(Url).filter_by(status='1').all()

    sel_blacklist = session.query(BlackList.nome).filter_by(status='1').all()
    str_blacklist= [ k[0]  for k in sel_blacklist ]

    for pg  in sel[0:2]:
        sel_estado = session.query(Estados).filter_by(url_id=pg.estado).all()
        str_regiao = sel_estado and sel_estado[0].regiao

        sel_whitelist = session.query(WhilteList.nome).filter_by(sessao=pg.sessao).all()
        str_whitelist= [ k[0]  for k in sel_whitelist ]
        try:
            print 'Lendo : ',pg.id,' -- ', pg.nome
            f = urllib.urlopen(pg.nome)
            _html = f.read()
        except :
            print 'Servidor não acessivel'
            continue
        try:
            #############################
            # Filtrar Html principal    #
            #############################


            soup = BeautifulSoup(_html)
            for link in soup.find_all('a'):
                link_int = link.get('href','')
                if not check_data(link_int.lower() ,[ '.html','.htm']):
                    continue
                print '-->', link_int
                try:
                    f_int = urllib.urlopen(link_int)
                    html_int = f_int.read()
                except :
                    continue

                ###########################
                # Leitura do anuncio      #
                ###########################
                soup_int = BeautifulSoup(html_int)
                texto = soup_int.find('section', id="userbody")
                if not texto :
                    texto = soup_int.text
                else:
                    texto = texto.text

                #########################
                # White List            #
                #########################
                in_white_list = (str_whitelist and check_data(texto ,str_whitelist)) or ( not str_whitelist )


                #########################
                # Black List            #
                #########################
                in_blak_list = False
                if in_white_list  and check_data(texto ,str_blacklist):
                    in_blak_list = True
                    print 'Black List '

                if in_blak_list:
                    continue

                #######################
                # Tratar anuncio p/   #
                #    Insercao         #
                ############################
                # Não esta na Black List   #
                # Esta na White List ou [] #
                ############################
                try:
                    time_sec = soup_int.find('time').text
                    body_sec = soup_int.find('section', id="userbody")
                    body_texto = body_sec.text
                    email = soup_int.find('span',id='replytext')
                    email = email.find_next("a").text
                    if not email or not '@' in email:
                        tipo_mail = -1
                        email = ''
                    elif ('craiglist.org') in email:
                        tipo_mail = 0
                    else:
                        tipo_mail = 1

                    titulo = soup_int.find_all('title')[0].text
                    titulo_id = re.sub(r"[^A-Za-z0-9]",'_',titulo).replace('__','_')
                    phone = get_phone(body_texto )
                    tags = get_tags(body_texto )
                    time_sec = datetime.strptime(time_sec[:19], "%Y-%m-%d, %I:%M%p")
                except :
                    continue
                    #raise


                try:
                    sel_anuncio = session_cm.query(Anuncios).filter_by(url_id=titulo_id).first()
                    if not sel_anuncio :

                        session_cm.add_all([Anuncios(
                                k=chave(),
                                nome = titulo,
                                url_id = titulo_id,
                                url = link_int,
                                html = soup_int.encode('utf-8'),
                                tags = tags,
                                cidade = pg.cidade,
                                estado = pg.estado,
                                regiao = str_regiao,
                                sessao = pg.sessao,
                                has_phone = phone and 1 or 0,
                                emails_type = tipo_mail,
                                post_date = time_sec.strftime("%Y-%m-%d, %H:%M:00"),
                                status = '1'
                        )])
                        if tipo_mail in (1,2):
                            print '---> Ins Email'
                            session_cm.add_all([AnunciosEmails(
                                    k=chave(),
                                    nome = email,
                                    url_id = re.sub(r"[^A-Za-z0-9]",'_',email).replace('__','_'),
                                    tipo = tipo_mail == 1  and 'CRAIGSLIST'  or 'EXTERNAL',
                                    anuncio= titulo_id,
                                    regiao = str_regiao)])
                        if phone:
                            print '---> Ins Phone'
                            session_cm.add_all([AnunciosTelefones(
                                    k=chave(),
                                    nome = phone,
                                    url_id = re.sub(r"[^A-Za-z0-9]",'_',phone).replace('__','_'),
                                    anuncio= titulo_id)])

                    else:
                        sel_anuncio.nome = titulo
                        sel_anuncio.url_id = titulo_id
                        sel_anuncio.url = link_int
                        sel_anuncio.html = soup_int.encode('utf-8')
                        sel_anuncio.tags = tags.encode('utf-8')
                        sel_anuncio.cidade = pg.cidade
                        sel_anuncio.estado = pg.estado
                        sel_anuncio.regiao =str_regiao
                        sel_anuncio.sessao = pg.sessao
                        sel_anuncio.has_phone = phone and 1 or 0
                        sel_anuncio.post_date = time_sec.strftime("%Y-%m-%d, %H:%M:00")
                        sel_anuncio.status = '1'
                    session_cm.commit()
                except (OperationalError, IntegrityError ):
                    session_cm.rollback()
                    #raise;




            pg.status='3'
            session_cm.add(pg)
            session_cm.commit()
        except :
            raise

    print '--  Final ---'